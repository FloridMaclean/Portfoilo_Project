1) I worked solo for this project.
Name: Florid Rajesh Maclean

2) Not Applicable (NA)

3) Proximity: I tried to put all obects as readable as possible.
   Contrast: Colors I chose for the portfolio project is just basic black & white to create contrast and visible.
   Typography: Used some basic fonts that can be easily readable by the user to improve accecibility.

4) I refered the standards for designing a website online and try to impliment some functions based o it for example adding alt attribute to an image element etc.

5) For Search Engine Optimization (SEO), I wrote meta keywords and meta description for each page.